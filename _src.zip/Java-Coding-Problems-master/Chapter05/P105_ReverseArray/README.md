# Reversing an array
Write a program that reverses the given array.
