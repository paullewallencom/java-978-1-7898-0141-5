# Convert `List<V>` into `Map<K, List<V>>`

Write a program that converts `List<V>` into `Map<K, List<V>>`.
