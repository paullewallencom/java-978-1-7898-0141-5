# Replacing elements of a List
Write a program that replaces each element of a **List** with the result of applying a given operator to it.
