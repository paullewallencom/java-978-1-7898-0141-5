# Assigning an array to var
Write a program that assigns an array to **var**.
