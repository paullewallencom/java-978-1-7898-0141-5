# Simple var example
Write a program that exemplifies the correct usage of type inference (**var**) with respect to the code readability.
