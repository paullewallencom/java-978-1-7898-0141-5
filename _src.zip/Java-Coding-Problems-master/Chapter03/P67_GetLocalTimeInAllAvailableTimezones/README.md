# Get local date-time in all available time zones
Write a program that displays the local time in all the available time zones.
