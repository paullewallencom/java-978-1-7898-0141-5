# Iterate a range of dates
Write a program that iterates a range of given dates, day by day (with a step of a day).
