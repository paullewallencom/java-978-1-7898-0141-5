# Remove leading and trailing spaces
Write a program that removes leading and trailing spaces of the given string.