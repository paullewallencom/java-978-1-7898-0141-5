# Join multiple strings with a delimiter
Write a program that joins the given strings by the given delimiter.