# Check if contains only digits
Write a program that checks if the given string contains only digits.