# Switch expressions
Provide a brief overview of **switch** expressions in JDK 12.
