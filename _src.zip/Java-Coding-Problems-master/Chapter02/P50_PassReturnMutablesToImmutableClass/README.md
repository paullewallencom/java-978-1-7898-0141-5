# Passing/returning mutable objects to/from immutable class
Write a program that passes and returns a mutable object to/from an immutable class.