# Equals and hashCode
Explain and exemplify how **equals()** and **hashCode()** methods works in Java.
