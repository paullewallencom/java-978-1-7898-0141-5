package modern.challenge;

public class Team extends SportType {    
}
