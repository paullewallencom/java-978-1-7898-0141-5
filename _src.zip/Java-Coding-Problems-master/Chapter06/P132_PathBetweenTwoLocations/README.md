# Constructing a path between two locations
Write several examples that constructs a relative path between two given paths (from one path to another).
